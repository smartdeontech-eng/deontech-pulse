// ---- Sessions, one-time codes, lockout ----
//
// The machinery behind every way a person signs in: the session cookie, the
// login log, the 6-digit codes, the WebAuthn challenge cookies, and the
// brute-force lockout. Extracted from routes/auth.js in both applications,
// where 264 and 248 lines of it sat side by side at 69% similarity.
//
// THE DIVERGENCE HERE WAS SECURITY BUGS, and each fork had ones the other did
// not. All three fixes below are now in one place:
//
//  1. clientIp (from Smart DeonTech). AOTC Track reads the first value of a raw
//     X-Forwarded-For header, which any client can set — so anyone could name
//     their own IP, poisoning the login log and, where it exists, defeating
//     new-device detection. req.ip honours Express's `trust proxy`, so it is
//     the address nginx actually saw.
//
//  2. recentFailedAttempts (from AOTC Track). Smart DeonTech counts every
//     login_logs row with success:false as a failed attempt — but
//     'awaiting-2fa' and 'must-change-password' are logged that way and mean
//     the PASSWORD WAS CORRECT. A user who signs in a few times in one window
//     with 2FA on gets locked out of their own account.
//
//  3. canActOn (from Smart DeonTech). Editing someone's email, resetting their
//     password or deleting them is effectively control of that account: change
//     the email and the reset link arrives in your inbox. Smart DeonTech
//     guards this by tier; AOTC Track has no equivalent, so anyone holding
//     staff.manage can act on a Local Admin.
//
// Everything is injected — db, jwt, the mail and SMS senders — for the reasons
// the other packages are: a shared package cannot reach the app's data, and it
// must not own the app's choice of library version.
const { appConfig } = require('@deontech/config');

const OTP_TTL_MS = 10 * 60 * 1000;
const LOCKOUT_THRESHOLD = 5;                 // failed attempts...
const LOCKOUT_WINDOW_MS = 15 * 60 * 1000;    // ...within this window...
const LOCKOUT_DURATION_MS = 15 * 60 * 1000;  // ...trigger this long a cooldown

// Rows logged success:false that are NOT failed attempts. 'awaiting-2fa' and
// 'must-change-password' both mean the password was correct.
// 'login-otp-sent' joins them: asking for the code you were just told to enter
// is not a failed attempt either, and counting it would lock someone out for
// clicking "send it again" five times — the same class of bug as 2 above.
const NOT_A_FAILURE = new Set([
  'locked-out', 'awaiting-2fa', 'must-change-password',
  'login-otp-sent', 'no-2fa-code-issued', 'password-reset',
]);

function createSession({
  db,
  jwt,
  jwtSecret,
  sendMail,
  sendSms,
  // Account tiers, used to stop a lower-tier account taking over a higher one.
  // Anything unlisted is tier 1. Mirrors @deontech/auth's admin model:
  // { admin: 3, manager: 2 } / { admin: 3, localadmin: 2 }.
  roleTiers = {},
  // Called when a successful sign-in comes from an IP+browser pair never seen
  // before on this account. A hook because where such an alert goes — push,
  // email, nowhere — is the application's policy, not this package's.
  onNewDevice,
  isProduction = process.env.NODE_ENV === 'production',
}) {
  if (!db || typeof db.findById !== 'function') throw new Error('createSession() needs the app datastore.');
  if (!jwt || typeof jwt.sign !== 'function') throw new Error("createSession() needs the app's jsonwebtoken module.");
  if (!jwtSecret) throw new Error('createSession() needs jwtSecret. The app must refuse to start without one.');
  if (typeof sendMail !== 'function') throw new Error('createSession() needs sendMail — codes have to reach people.');

  // ---- Session cookie -----------------------------------------------------
  // `secure` only in production: localhost dev is plain HTTP and browsers
  // silently drop secure cookies over HTTP, which would break local testing.
  function cookieOptions(maxAge) {
    return { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge };
  }

  // Session length: 12 hours normally, 30 days if "Remember me" was checked.
  function sessionDuration(remember) {
    return remember
      ? { expiresIn: '30d', maxAge: 30 * 24 * 60 * 60 * 1000 }
      : { expiresIn: '12h', maxAge: 12 * 60 * 60 * 1000 };
  }

  // The "you're now logged in" step, shared by password, 2FA, OTP and passkey
  // logins, so every path sets an identical cookie and claims. Embeds the
  // account's current sessionVersion so a later bump invalidates this token.
  function finalizeLogin(res, user, remember) {
    const { expiresIn, maxAge } = sessionDuration(remember);
    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role: user.role, sv: user.sessionVersion || 0 },
      jwtSecret,
      { expiresIn }
    );
    res.cookie('token', token, cookieOptions(maxAge));
    return { id: user.id, name: user.name, email: user.email, role: user.role, permissions: user.permissions || [] };
  }

  // Invalidates every session token issued before this call. Used wherever a
  // password is reset on someone's behalf, so a compromised session cannot
  // ride out its remaining cookie lifetime — up to 30 days.
  function bumpSessionVersion(userId, extraPatch = {}) {
    const user = db.findById('users', userId);
    if (!user) return null;
    return db.update('users', userId, { sessionVersion: (user.sessionVersion || 0) + 1, ...extraPatch });
  }

  // Never let a hash, secret or stored public key out of the API.
  function safeUser(user) {
    const {
      passwordHash, twoFactorSecret, twoFactorTempSecret, backupCodeHashes, passwordResetTokenHash,
      twoFactorTempOtpHash, loginOtpHash, stepUpOtpHash, passkeys, twoFactorDevices, twoFactorDeviceTemp, ...safe
    } = user;
    safe.authenticators = (user.twoFactorSecret ? [{ id: 'main', name: user.twoFactorMainName || 'First authenticator' }] : [])
      .concat((twoFactorDevices || []).map(d => ({ id: d.id, name: d.name, createdAt: d.createdAt, lastUsedAt: d.lastUsedAt })));
    safe.passkeys = (passkeys || []).map(p => ({
      id: p.id, deviceName: p.deviceName, createdAt: p.createdAt, lastUsedAt: p.lastUsedAt,
    }));
    return safe;
  }

  // ---- Login log ----------------------------------------------------------
  // FIX (was AOTC Track's bug): req.ip honours Express's `trust proxy`, so it
  // is the address nginx actually saw. Reading the first value of a raw
  // X-Forwarded-For header lets any client name its own IP.
  function clientIp(req) {
    return req.ip || (req.socket && req.socket.remoteAddress) || '';
  }

  function logLogin(entry) {
    // A genuinely new device/location for a SUCCESSFUL sign-in: neither this IP
    // nor this browser has been seen on a prior successful login. Checked
    // before inserting the current row so it isn't matched against itself.
    let isNewDevice = false;
    try {
      if (entry.success && entry.reason === 'ok' && entry.userId) {
        // Both signals must match the SAME earlier sign-in. Either one alone
        // meant an attacker who simply copied the victim's User-Agent — a
        // header they choose — silently suppressed the alert. Requiring both
        // also fails safe: an unknown IP matches nothing and the alert fires.
        const known = db.findAll('login_logs', l =>
          l.userId === entry.userId && l.success &&
          entry.ip && l.ip === entry.ip &&
          entry.userAgent && l.userAgent === entry.userAgent
        );
        isNewDevice = known.length === 0;
      }
    } catch (e) { /* non-fatal */ }

    try {
      db.insert('login_logs', { event: 'login', ip: '', userAgent: '', ...entry });
    } catch (e) {
      console.error('[login-log] failed to write log entry:', e.message);
    }

    if (isNewDevice && typeof onNewDevice === 'function') {
      try {
        onNewDevice(entry);
      } catch (e) {
        console.error('[login-log] new-device handler failed:', e.message);
      }
    }
  }

  // ---- One-time codes -----------------------------------------------------
  // 6 digits, hashed at rest, valid for 10 minutes. Used to confirm a channel
  // during 2FA setup and as the login second factor for email or SMS.
  function generateOtp() {
    return String(require('crypto').randomInt(0, 1000000)).padStart(6, '0');
  }
  function maskEmail(email) {
    const [name, domain] = String(email || '').split('@');
    if (!domain) return email || '';
    return `${name.slice(0, 1)}${'•'.repeat(Math.max(1, name.length - 1))}@${domain}`;
  }
  function maskPhone(phone) {
    const d = String(phone || '').replace(/\D/g, '');
    if (d.length < 3) return '•••';
    return `•••••${d.slice(-3)}`;
  }

  // Deliver a code by the user's chosen method. Returns a masked destination
  // for the UI, or null if the channel isn't usable.
  async function deliverOtp(user, method, code, purpose) {
    const { productName } = appConfig();
    const isSetup = purpose === 'setup';
    const line = `Your ${productName} ${isSetup ? 'verification' : 'login'} code is ${code}. It expires in 10 minutes.`;
    if (method === 'email') {
      if (!user.email) return null;
      // DEV FALLBACK (from AOTC Track): with no SMTP configured locally, print
      // the code rather than failing. Never active in production.
      if (!process.env.SMTP_HOST && !isProduction) {
        console.log(`[dev-otp] ${purpose} code for ${user.email}: ${code}`);
        return maskEmail(user.email) + ' (dev: see server console)';
      }
      // The RESULT IS READ, not assumed. sendMail reports an unconfigured
      // transport or a refused message by RETURNING { skipped } / { error };
      // it does not throw. This branch ignored that and returned a masked
      // address either way, so the screen said "we sent a code to a•••@x.com"
      // when nothing had been sent and nothing could arrive — and the person
      // sat waiting for a code that did not exist. The SMS branch below has
      // always checked. The asymmetry between the two was the bug.
      const r = await sendMail({
        to: user.email,
        subject: `${productName} ${isSetup ? 'verification' : 'login'} code`,
        html: `<p>${line}</p><p style="color:#667">If you didn't request this, you can ignore this email.</p>`,
      });
      if (r && (r.skipped || r.error)) {
        console.error(`[otp] could not email the ${purpose} code to ${user.email}: ${r.skipped || r.error}`);
        return null;
      }
      return maskEmail(user.email);
    }
    if (method === 'sms') {
      if (!user.phone || typeof sendSms !== 'function') return null;
      const r = await sendSms({ to: user.phone, message: line });
      if (r && (r.skipped || r.error)) return null;
      return maskPhone(user.phone);
    }
    return null;
  }

  // ---- WebAuthn challenge cookies ----------------------------------------
  // Short-lived and signed, so a client-supplied challenge is never trusted.
  function setChallengeCookie(res, name, payload) {
    const token = jwt.sign(payload, jwtSecret, { expiresIn: '5m' });
    res.cookie(name, token, { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge: 5 * 60 * 1000 });
  }
  function readChallengeCookie(req, name, expectedPurpose) {
    const raw = req.cookies && req.cookies[name];
    if (!raw) return null;
    try {
      const payload = jwt.verify(raw, jwtSecret);
      if (payload.purpose !== expectedPurpose) return null;
      return payload;
    } catch (e) {
      return null;
    }
  }

  // ---- Lockout ------------------------------------------------------------
  // Built on the login_logs history already recorded — no extra state.
  function recentFailedAttempts(email) {
    const since = Date.now() - LOCKOUT_WINDOW_MS;
    const lower = String(email).toLowerCase();
    const mine = l => l.email && String(l.email).toLowerCase() === lower;

    // A COMPLETED PASSWORD RESET ENDS THE SUSPICION.
    //
    // Somebody who proved control of the mailbox on file and chose a new
    // password is not who the lockout was protecting the account from — and
    // the five failures that preceded it were, by definition, this person
    // forgetting their password. Left in place, the lockout makes the reset
    // look broken: new password, still refused, for up to fifteen more
    // minutes, with nothing on screen saying why. That is the moment someone
    // stops trusting the software and telephones the Secretariat.
    //
    // It grants nothing: completing a reset already means holding the account.
    const clearedTo = db.findAll('login_logs', l => mine(l) && l.reason === 'password-reset')
      .reduce((t, l) => Math.max(t, new Date(l.createdAt).getTime()), 0);

    return db.findAll('login_logs', l =>
      mine(l) && new Date(l.createdAt).getTime() > clearedTo &&
      // FIX (was Smart DeonTech's bug): 'awaiting-2fa' and
      // 'must-change-password' are logged success:false but mean the password
      // was CORRECT. Counting them locks legitimate users out of their own
      // accounts for signing in a few times in one window.
      !l.success && !NOT_A_FAILURE.has(l.reason) &&
      new Date(l.createdAt).getTime() > since
    );
  }

  function checkLockout(email) {
    const attempts = recentFailedAttempts(email);
    if (attempts.length < LOCKOUT_THRESHOLD) return null;
    const mostRecent = attempts.reduce((a, b) => new Date(a.createdAt) > new Date(b.createdAt) ? a : b);
    const msRemaining = new Date(mostRecent.createdAt).getTime() + LOCKOUT_DURATION_MS - Date.now();
    if (msRemaining <= 0) return null;
    return Math.ceil(msRemaining / 60000); // minutes
  }

  // ---- Account tiers ------------------------------------------------------
  // Editing someone's email, resetting their password or deleting them is
  // effectively control of that account. Acting on yourself is always allowed;
  // otherwise the caller must be at least the target's tier.
  function roleTier(role) {
    return roleTiers[role] || 1;
  }
  function canActOn(actor, target) {
    if (!actor || !target) return false;
    if (actor.id === target.id) return true;
    return roleTier(actor.role) >= roleTier(target.role);
  }

  return {
    cookieOptions, sessionDuration, finalizeLogin, bumpSessionVersion, safeUser,
    clientIp, logLogin,
    generateOtp, maskEmail, maskPhone, deliverOtp,
    setChallengeCookie, readChallengeCookie,
    recentFailedAttempts, checkLockout,
    roleTier, canActOn,
    OTP_TTL_MS, LOCKOUT_THRESHOLD, LOCKOUT_WINDOW_MS, LOCKOUT_DURATION_MS,
  };
}

module.exports = { createSession, NOT_A_FAILURE, OTP_TTL_MS };
