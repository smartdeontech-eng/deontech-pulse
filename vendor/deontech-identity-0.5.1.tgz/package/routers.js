// ---- Mountable sign-in routers ----
//
// The passkey and two-factor endpoints were byte-identical in both
// applications: 338 lines, 100% the same apart from one string (the TOTP
// issuer, which is the product name). Measured across routes/auth.js, 548 of
// the shared lines are at 97% or better; these are the two flows where the
// logic is real and where drift has already produced security bugs, so they
// are the ones that most need to stop being two files.
//
// These own URL paths and response shapes, which is a wider interface than the
// rest of this workspace has. That is deliberate and bounded: the routes were
// already identical, so the interface was discovered rather than designed. The
// moment an application needs a different path or payload here, it should take
// its own copy back rather than the package growing an option.
//
// express is injected along with everything else — the application owns its
// version, and this package still has no third-party dependency.
const { appConfig } = require('@deontech/config');

function createAuthRouters({
  express, db, jwt, jwtSecret, bcrypt, totp, webauthn, QRCode,
  session,      // the object returned by createSession()
  requireAuth,
  // Optional: told when an authenticator is added or removed, so an app that
  // watches its own security (Pulse) can raise an alert.
  onSecurityEvent,
}) {
  for (const [name, v] of Object.entries({ express, db, jwt, jwtSecret, bcrypt, totp, webauthn, session, requireAuth })) {
    if (!v) throw new Error(`createAuthRouters() needs ${name}.`);
  }
  // Which of the account's authenticators a code came from ('main' or a
  // device id), or null. Written against the injected totp, so tests and apps
  // that pass their own still work.
  function matchAuth(user, token) {
    if (!user) return null;
    const t = String(token || '').trim();
    if (!t) return null;
    if (user.twoFactorSecret && totp.verifyToken(user.twoFactorSecret, t)) return 'main';
    const d = (user.twoFactorDevices || []).find(x => x && x.secret && totp.verifyToken(x.secret, t));
    return d ? d.id : null;
  }
  const {
    clientIp, logLogin, checkLockout, finalizeLogin,
    setChallengeCookie, readChallengeCookie, generateOtp, deliverOtp, OTP_TTL_MS,
  } = session;

  // ================= Passkeys / biometric login (WebAuthn) =================
  // A passkey lets someone sign in with the phone's Face ID / fingerprint (or a
  // laptop's Touch ID / Windows Hello) instead of typing a password. It's a
  // public-key credential bound to this site and this device: the private key
  // never leaves the device's secure hardware, and unlocking it requires the
  // user's biometric — so a passkey is already two factors (device + biometric)
  // and a passkey login does NOT then ask for a TOTP code. Passwords still get
  // the normal 2FA step.
  //
  // Storage: user.passkeys = [{ id, publicKey, counter, transports, deviceName,
  // createdAt, lastUsedAt }], id/publicKey base64url-encoded strings.
  const passkeyRouter = express.Router();

  function findUserByPasskeyId(credId) {
    return db.findOne('users', u => (u.passkeys || []).some(p => p.id === credId));
  }

  // Step 1 of enrolment: hand the browser a challenge + params. Auth required —
  // you enrol a device only while already logged in.
  passkeyRouter.post('/passkey/register/options', requireAuth, async (req, res) => {
    const user = db.findById('users', req.user.id);
    const { rpName, rpID, origin } = webauthn.getRP(req);
    try {
      const options = await webauthn.generateRegistrationOptions({
        rpName,
        rpID,
        userID: Buffer.from(String(user.id)),
        userName: user.email,
        userDisplayName: user.name,
        attestationType: 'none',
        excludeCredentials: (user.passkeys || []).map(p => ({ id: p.id, transports: p.transports })),
        authenticatorSelection: { residentKey: 'preferred', userVerification: 'preferred' },
      });
      setChallengeCookie(res, 'wa_reg', { purpose: 'wa-reg', uid: user.id, challenge: options.challenge, origin, rpID });
      res.json(options);
    } catch (e) {
      console.error('[passkey] register options failed:', e.message);
      res.status(500).json({ error: 'Could not start passkey setup.' });
    }
  });

  // Step 2 of enrolment: verify the attestation and store the credential.
  passkeyRouter.post('/passkey/register/verify', requireAuth, async (req, res) => {
    const user = db.findById('users', req.user.id);
    const chal = readChallengeCookie(req, 'wa_reg', 'wa-reg');
    res.clearCookie('wa_reg');
    if (!chal || chal.uid !== user.id) {
      return res.status(400).json({ error: 'Setup expired. Please try again.' });
    }
    try {
      const verification = await webauthn.verifyRegistrationResponse({
        response: req.body.attResp,
        expectedChallenge: chal.challenge,
        expectedOrigin: chal.origin,
        expectedRPID: chal.rpID,
        requireUserVerification: false,
      });
      if (!verification.verified || !verification.registrationInfo) {
        return res.status(400).json({ error: 'Could not verify this device. Please try again.' });
      }
      const cred = verification.registrationInfo.credential;
      const passkeys = user.passkeys || [];
      if (passkeys.some(p => p.id === cred.id)) {
        return res.status(409).json({ error: 'This device is already set up.' });
      }
      const deviceName = String(req.body.deviceName || '').trim().slice(0, 40) || 'This device';
      passkeys.push({
        id: cred.id,
        publicKey: Buffer.from(cred.publicKey).toString('base64url'),
        counter: cred.counter || 0,
        transports: cred.transports || (req.body.attResp && req.body.attResp.response && req.body.attResp.response.transports) || [],
        deviceName,
        createdAt: new Date().toISOString(),
        lastUsedAt: null,
      });
      db.update('users', user.id, { passkeys });
      res.json({ ok: true, passkey: { id: cred.id, deviceName, createdAt: passkeys[passkeys.length - 1].createdAt } });
    } catch (e) {
      console.error('[passkey] register verify failed:', e.message);
      res.status(400).json({ error: 'Could not verify this device. Please try again.' });
    }
  });

  passkeyRouter.get('/passkey/list', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    res.json({
      passkeys: (user.passkeys || []).map(p => ({
        id: p.id, deviceName: p.deviceName, createdAt: p.createdAt, lastUsedAt: p.lastUsedAt,
      })),
    });
  });

  passkeyRouter.delete('/passkey/:id', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    const passkeys = user.passkeys || [];
    const next = passkeys.filter(p => p.id !== req.params.id);
    if (next.length === passkeys.length) return res.status(404).json({ error: 'Passkey not found.' });
    db.update('users', user.id, { passkeys: next });
    res.json({ ok: true });
  });

  // Login step 1: hand the browser a challenge. allowCredentials is left empty
  // so the browser offers whatever discoverable passkeys it holds for this site
  // — the user just taps and authenticates, no email typed. No auth here (this
  // IS the login).
  passkeyRouter.post('/passkey/login/options', async (req, res) => {
    const { rpID, origin } = webauthn.getRP(req);
    try {
      const options = await webauthn.generateAuthenticationOptions({
        rpID,
        allowCredentials: [],
        userVerification: 'preferred',
      });
      setChallengeCookie(res, 'wa_auth', {
        purpose: 'wa-auth', challenge: options.challenge, origin, rpID, remember: !!req.body.remember,
      });
      res.json(options);
    } catch (e) {
      console.error('[passkey] login options failed:', e.message);
      res.status(500).json({ error: 'Could not start biometric sign-in.' });
    }
  });

  // Login step 2: verify the assertion, find the owning user, issue the session.
  passkeyRouter.post('/passkey/login/verify', async (req, res) => {
    const ip = clientIp(req);
    const userAgent = req.get('user-agent') || '';
    const chal = readChallengeCookie(req, 'wa_auth', 'wa-auth');
    res.clearCookie('wa_auth');
    if (!chal) return res.status(400).json({ error: 'Sign-in expired. Please try again.' });

    const authResp = req.body.authResp;
    if (!authResp || !authResp.id) return res.status(400).json({ error: 'No passkey provided.' });

    const user = findUserByPasskeyId(authResp.id);
    const passkey = user && (user.passkeys || []).find(p => p.id === authResp.id);
    if (!user || !passkey) {
      logLogin({ userId: null, email: null, success: false, reason: 'passkey-unknown', ip, userAgent });
      return res.status(401).json({ error: 'This passkey isn\'t recognised. Sign in with your password.' });
    }

    const minutesLeft = checkLockout(user.email);
    if (minutesLeft !== null) {
      logLogin({ userId: user.id, email: user.email, success: false, reason: 'locked-out', ip, userAgent });
      return res.status(429).json({ error: `Too many failed attempts. Please try again in about ${minutesLeft} minute${minutesLeft === 1 ? '' : 's'}.` });
    }

    try {
      const verification = await webauthn.verifyAuthenticationResponse({
        response: authResp,
        expectedChallenge: chal.challenge,
        expectedOrigin: chal.origin,
        expectedRPID: chal.rpID,
        requireUserVerification: false,
        credential: {
          id: passkey.id,
          publicKey: Buffer.from(passkey.publicKey, 'base64url'),
          counter: passkey.counter || 0,
          transports: passkey.transports || [],
        },
      });
      if (!verification.verified) {
        logLogin({ userId: user.id, email: user.email, success: false, reason: 'passkey-failed', ip, userAgent });
        return res.status(401).json({ error: 'Biometric sign-in failed. Please try again.' });
      }
      // Bump the signature counter (clone/replay detection) and stamp last use.
      const passkeys = user.passkeys.map(p => p.id === passkey.id
        ? { ...p, counter: verification.authenticationInfo.newCounter, lastUsedAt: new Date().toISOString() }
        : p);
      db.update('users', user.id, { passkeys });

      // A forced password change (new account, or an admin/self reset) must
      // hold here too — otherwise a passkey would bypass it entirely, since
      // this is a separate login path from the password form that normally
      // enforces it.
      if (user.mustChangePassword) {
        const pendingToken = jwt.sign({ id: user.id, purpose: 'password-change-required', remember: !!chal.remember }, jwtSecret, { expiresIn: '10m' });
        logLogin({ userId: user.id, email: user.email, success: false, reason: 'must-change-password', ip, userAgent });
        return res.json({ mustChangePassword: true, pendingToken });
      }

      logLogin({ userId: user.id, email: user.email, success: true, reason: 'ok-via-passkey', ip, userAgent });
      res.json(finalizeLogin(res, user, chal.remember));
    } catch (e) {
      console.error('[passkey] login verify failed:', e.message);
      logLogin({ userId: user.id, email: user.email, success: false, reason: 'passkey-error', ip, userAgent });
      res.status(400).json({ error: 'Biometric sign-in failed. Please try again.' });
    }
  });

  // ========================= Two-factor =========================
  const twoFactorRouter = express.Router();

  // How long before the same account may ask for another code. The endpoint
  // sends mail to an address chosen by whoever holds the pending token, so
  // without this one stolen password is a mail cannon pointed at that person's
  // inbox — and at the federation's sending reputation.
  const OTP_RESEND_MS = 60 * 1000;

  // ---- Issue the login second factor for an email or SMS account ----------
  //
  // THE HALF OF THIS FLOW THAT DID NOT EXIST.
  //
  // verify-2fa below has always read user.loginOtpHash. Nothing in this
  // package, and nothing in either application, ever WROTE it. So an account
  // with twoFactorMethod 'email' or 'sms' could not complete a sign-in ever
  // again: the password was accepted, the screen asked for a code, no code was
  // sent, and no code could have verified if one had been. The only way back
  // in was a backup code — shown once, at enrolment, and by then filed
  // somewhere or lost.
  //
  // It survived 187 passing tests because the fixtures plant a hash by hand.
  // A test proving the verifier works is not a test that the code can be
  // obtained, and the gap between those two is where this lived.
  twoFactorRouter.post('/login/send-2fa-code', async (req, res) => {
    const { pendingToken } = req.body || {};
    const ip = clientIp(req);
    const userAgent = req.get('user-agent') || '';
    if (!pendingToken) return res.status(400).json({ error: 'Missing session. Please log in again.' });

    let payload;
    try {
      payload = jwt.verify(pendingToken, jwtSecret);
      if (payload.purpose !== '2fa-pending') throw new Error('wrong purpose');
    } catch (e) {
      return res.status(401).json({ error: 'This verification step expired. Please log in again.' });
    }

    const user = db.findById('users', payload.id);
    if (!user || !user.twoFactorEnabled) return res.status(401).json({ error: 'Please log in again.' });

    // The same cooldown that guards verify-2fa guards this. An account being
    // brute-forced should not also be emailing its owner a code a second.
    const minutesLeft = checkLockout(user.email);
    if (minutesLeft !== null) {
      return res.status(429).json({ error: `Too many failed attempts. Please try again in about ${minutesLeft} minute${minutesLeft === 1 ? '' : 's'}.` });
    }

    const method = user.twoFactorMethod || 'totp';
    if (method !== 'email' && method !== 'sms') {
      // An authenticator app generates its own codes; there is nothing to send.
      return res.status(400).json({ error: 'This account uses an authenticator app. Enter the code it shows.' });
    }

    const since = Date.now() - (user.loginOtpIssuedAt || 0);
    if (user.loginOtpIssuedAt && since < OTP_RESEND_MS) {
      const wait = Math.ceil((OTP_RESEND_MS - since) / 1000);
      return res.status(429).json({ error: `A code was just sent. Please wait ${wait} second${wait === 1 ? '' : 's'} before asking for another.` });
    }

    const code = generateOtp();
    let sentTo;
    try {
      sentTo = await deliverOtp(user, method, code, 'login');
    } catch (e) {
      console.error('[2fa-login] send failed:', e.message);
      return res.status(502).json({ error: 'Could not send your code right now. Please try again in a moment.' });
    }
    // deliverOtp returns null when the channel could not actually carry it —
    // no address on file, SMTP unconfigured, the gateway refusing. Saying so is
    // the point: a person who is told the code is coming will wait for it.
    if (!sentTo) {
      return res.status(502).json({
        error: `Your code could not be sent to your ${method === 'email' ? 'email address' : 'phone'}. Use a backup code, or ask an administrator.`,
      });
    }

    // Stored only AFTER delivery succeeded. Writing the hash first would start
    // the ten-minute clock on a code nobody received, and burn the resend
    // cooldown on a message that never left.
    db.update('users', user.id, {
      loginOtpHash: bcrypt.hashSync(code, 10),
      loginOtpExpires: Date.now() + OTP_TTL_MS,
      loginOtpIssuedAt: Date.now(),
    });
    logLogin({ userId: user.id, email: user.email, success: false, reason: 'login-otp-sent', ip, userAgent });

    res.json({ sentTo, expiresInMs: OTP_TTL_MS });
  });

  twoFactorRouter.post('/login/verify-2fa', (req, res) => {
    const { pendingToken, code, backupCode } = req.body;
    const ip = clientIp(req);
    const userAgent = req.get('user-agent') || '';
    if (!pendingToken) return res.status(400).json({ error: 'Missing session. Please log in again.' });

    let payload;
    try {
      payload = jwt.verify(pendingToken, jwtSecret);
      if (payload.purpose !== '2fa-pending') throw new Error('wrong purpose');
    } catch (e) {
      return res.status(401).json({ error: 'This verification step expired. Please log in again.' });
    }

    const user = db.findById('users', payload.id);
    if (!user || !user.twoFactorEnabled) return res.status(401).json({ error: 'Please log in again.' });

    const minutesLeft = checkLockout(user.email);
    if (minutesLeft !== null) {
      logLogin({ userId: user.id, email: user.email, success: false, reason: 'locked-out', ip, userAgent });
      return res.status(429).json({ error: `Too many failed attempts. Please try again in about ${minutesLeft} minute${minutesLeft === 1 ? '' : 's'}.` });
    }

    const method = user.twoFactorMethod || 'totp';
    let ok = false;
    let usedBackupCode = null;
    let noCodeIssued = false;
    let reason = 'ok-via-2fa';
    if (backupCode) {
      const hashes = user.backupCodeHashes || [];
      const idx = hashes.findIndex(h => bcrypt.compareSync(String(backupCode).trim(), h));
      if (idx !== -1) { ok = true; usedBackupCode = idx; reason = 'ok-via-backup-code'; }
    } else if (code) {
      if (method === 'email' || method === 'sms') {
        // Distinguished from a wrong code deliberately. While no endpoint
        // issued these at all, every attempt came back "Incorrect code" —
        // which is what let a flow that could not work look like a user
        // mistyping, for as long as it did.
        if (!user.loginOtpHash) noCodeIssued = true;
        const notExpired = user.loginOtpHash && user.loginOtpExpires && Date.now() < user.loginOtpExpires;
        ok = !!notExpired && bcrypt.compareSync(String(code).trim(), user.loginOtpHash);
        reason = `ok-via-${method}-otp`;
      } else {
        // Any of the account's authenticators: a second phone has its own secret.
        const which = matchAuth(user, code);
        ok = !!which;
        if (which && which !== 'main') {
          db.update('users', user.id, { twoFactorDevices: (user.twoFactorDevices || []).map(d => (d.id === which ? { ...d, lastUsedAt: new Date().toISOString() } : d)) });
        }
      }
    }

    if (!ok) {
      // No code outstanding is not a failed attempt — there is nothing to
      // guess — so it must not count towards the lockout that would then
      // keep the account out for another fifteen minutes.
      if (noCodeIssued) {
        logLogin({ userId: user.id, email: user.email, success: false, reason: 'no-2fa-code-issued', ip, userAgent });
        return res.status(400).json({ error: 'No code has been sent yet. Ask for one, then enter it here.' });
      }
      logLogin({ userId: user.id, email: user.email, success: false, reason: 'invalid-2fa-code', ip, userAgent });
      return res.status(401).json({ error: 'Incorrect code. Please try again.' });
    }

    const patch = {};
    if (usedBackupCode !== null) {
      patch.backupCodeHashes = (user.backupCodeHashes || []).filter((_, i) => i !== usedBackupCode);
    }
    // Burn a used email/SMS code so it can't be replayed.
    if (method === 'email' || method === 'sms') {
      patch.loginOtpHash = null;
      patch.loginOtpExpires = null;
      patch.loginOtpIssuedAt = null;
    }
    if (Object.keys(patch).length) db.update('users', user.id, patch);

    logLogin({ userId: user.id, email: user.email, success: true, reason, ip, userAgent });
    res.json(finalizeLogin(res, user, payload.remember));
  });

  twoFactorRouter.post('/2fa/setup', requireAuth, async (req, res) => {
    const { password } = req.body;
    const method = req.body.method || 'totp';
    const user = db.findById('users', req.user.id);
    if (!bcrypt.compareSync(password || '', user.passwordHash)) {
      return res.status(401).json({ error: 'Password is incorrect.' });
    }

    if (method === 'totp') {
      const secret = totp.generateSecret();
      db.update('users', user.id, { twoFactorTempSecret: secret, twoFactorTempMethod: 'totp' });
      // The only value in these two flows that was ever app-specific.
      const otpauthUrl = totp.otpauthURL({ issuer: appConfig().productName, accountName: user.email, secret });
      try {
        const qrCodeDataUrl = QRCode ? await QRCode.toDataURL(otpauthUrl) : null;
        return res.json({ method, secret, otpauthUrl, qrCodeDataUrl });
      } catch (e) {
        // QR generation failing should never block setup — the secret can be typed in manually.
        return res.json({ method, secret, otpauthUrl, qrCodeDataUrl: null });
      }
    }

    if (method === 'email' || method === 'sms') {
      if (method === 'sms' && !user.phone) {
        return res.status(400).json({ error: 'Add a phone number to your account first (ask an admin), then set up SMS codes.' });
      }
      const code = generateOtp();
      db.update('users', user.id, {
        twoFactorTempMethod: method,
        twoFactorTempSecret: null,
        twoFactorTempOtpHash: bcrypt.hashSync(code, 10),
        twoFactorTempOtpExpires: Date.now() + OTP_TTL_MS,
      });
      let sentTo;
      try {
        sentTo = await deliverOtp(user, method, code, 'setup');
      } catch (e) {
        console.error('[2fa-setup] send failed:', e.message);
        return res.status(502).json({ error: 'Could not send a test code right now. Please try again.' });
      }
      if (!sentTo) {
        return res.status(400).json({ error: `Couldn't send a code to your ${method === 'email' ? 'email' : 'phone'}. Check it's on file and able to receive messages.` });
      }
      return res.json({ method, sentTo });
    }

    return res.status(400).json({ error: 'Unknown 2FA method.' });
  });

  twoFactorRouter.post('/2fa/enable', requireAuth, (req, res) => {
    const { token } = req.body;
    const user = db.findById('users', req.user.id);
    const method = user.twoFactorTempMethod || (user.twoFactorTempSecret ? 'totp' : null);
    if (!method) return res.status(400).json({ error: 'Start setup again — nothing pending.' });

    let ok = false;
    if (method === 'totp') {
      ok = !!user.twoFactorTempSecret && totp.verifyToken(user.twoFactorTempSecret, token);
    } else if (method === 'email' || method === 'sms') {
      const notExpired = user.twoFactorTempOtpHash && user.twoFactorTempOtpExpires && Date.now() < user.twoFactorTempOtpExpires;
      ok = !!notExpired && bcrypt.compareSync(String(token || '').trim(), user.twoFactorTempOtpHash);
    }
    if (!ok) {
      const hint = method === 'totp' ? 'Check your authenticator app and try again.' : 'Check the code we sent and try again.';
      return res.status(400).json({ error: `Incorrect code. ${hint}` });
    }

    const backupCodes = totp.generateBackupCodes();
    const backupCodeHashes = backupCodes.map(c => bcrypt.hashSync(c, 10));
    db.update('users', user.id, {
      twoFactorEnabled: true,
      twoFactorMethod: method,
      twoFactorSecret: method === 'totp' ? user.twoFactorTempSecret : null,
      // Setting up afresh starts a fresh list of authenticators.
      twoFactorDevices: [], twoFactorMainName: null, twoFactorEnabledAt: new Date().toISOString(),
      twoFactorTempSecret: null,
      twoFactorTempMethod: null,
      twoFactorTempOtpHash: null,
      twoFactorTempOtpExpires: null,
      backupCodeHashes,
    });
    res.json({ ok: true, method, backupCodes });
  });

  // ---- More than one authenticator: a second phone (12 Oct 2026) --------
  //
  // Each phone gets its own secret, so a lost phone is removed on its own and
  // the others keep working. Adding or removing one needs a current code from
  // an authenticator the account already has: holding the password alone is
  // not enough to plant a second phone on someone's account. The last one
  // cannot be removed (an account with two-factor always has a way to give it).
  const DEVICE_SETUP_MS = 10 * 60 * 1000;
  const listOf = (user) => (user.twoFactorSecret ? [{ id: 'main', name: user.twoFactorMainName || 'First authenticator', createdAt: user.twoFactorEnabledAt || null }] : [])
    .concat((user.twoFactorDevices || []).map(d => ({ id: d.id, name: d.name, createdAt: d.createdAt, lastUsedAt: d.lastUsedAt || null })));
  const tell = (type, user, name) => { try { if (onSecurityEvent) onSecurityEvent({ type, user, name }); } catch (e) { console.error('[2fa] onSecurityEvent:', e.message); } };

  twoFactorRouter.get('/2fa/authenticators', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    res.json({ authenticators: (user.twoFactorMethod || 'totp') === 'totp' && user.twoFactorEnabled ? listOf(user) : [] });
  });

  twoFactorRouter.post('/2fa/authenticators/setup', requireAuth, async (req, res) => {
    const user = db.findById('users', req.user.id);
    if (!user.twoFactorEnabled || (user.twoFactorMethod || 'totp') !== 'totp') return res.status(400).json({ error: 'Set up an authenticator app first.' });
    if (!matchAuth(user, (req.body || {}).code)) return res.status(401).json({ error: 'That code is not right. Enter the code your current authenticator shows now.' });
    if ((user.twoFactorDevices || []).length >= 9) return res.status(400).json({ error: 'That is ten authenticators already: remove one first.' });
    const secret = totp.generateSecret();
    db.update('users', user.id, { twoFactorDeviceTemp: { secret, at: Date.now() } });
    const otpauthUrl = totp.otpauthURL({ issuer: appConfig().productName, accountName: user.email, secret });
    let qrCodeDataUrl = null;
    try { qrCodeDataUrl = QRCode ? await QRCode.toDataURL(otpauthUrl) : null; } catch (e) { /* the secret can be typed */ }
    res.json({ secret, otpauthUrl, qrCodeDataUrl });
  });

  twoFactorRouter.post('/2fa/authenticators/enable', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    const t = user.twoFactorDeviceTemp;
    if (!t || Date.now() - t.at > DEVICE_SETUP_MS) return res.status(400).json({ error: 'That took too long. Start again.' });
    if (!totp.verifyToken(t.secret, (req.body || {}).token)) return res.status(400).json({ error: 'Incorrect code. Enter the code the NEW phone shows.' });
    const name = String((req.body || {}).name || '').trim().slice(0, 60) || 'Another authenticator';
    const device = { id: require('crypto').randomBytes(6).toString('hex'), name, secret: t.secret, createdAt: new Date().toISOString(), lastUsedAt: null };
    db.update('users', user.id, { twoFactorDevices: (user.twoFactorDevices || []).concat([device]), twoFactorDeviceTemp: null });
    tell('authenticator-added', user, name);
    res.json({ ok: true, authenticators: listOf(db.findById('users', user.id)) });
  });

  twoFactorRouter.post('/2fa/authenticators/:id/remove', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    if (!matchAuth(user, (req.body || {}).code)) return res.status(401).json({ error: 'That code is not right. Enter a code from one of your authenticators.' });
    const all = listOf(user);
    const gone = all.find(a => a.id === req.params.id);
    if (!gone) return res.status(404).json({ error: 'No such authenticator.' });
    if (all.length < 2) return res.status(400).json({ error: 'This is your only authenticator. Add another first, then remove this one.' });
    let patch;
    if (gone.id === 'main') {
      // The next one takes its place.
      const [next, ...rest] = user.twoFactorDevices;
      patch = { twoFactorSecret: next.secret, twoFactorMainName: next.name, twoFactorDevices: rest };
    } else {
      patch = { twoFactorDevices: (user.twoFactorDevices || []).filter(d => d.id !== gone.id) };
    }
    db.update('users', user.id, patch);
    tell('authenticator-removed', user, gone.name);
    res.json({ ok: true, authenticators: listOf(db.findById('users', user.id)) });
  });

  twoFactorRouter.post('/2fa/authenticators/:id/rename', requireAuth, (req, res) => {
    const user = db.findById('users', req.user.id);
    const name = String((req.body || {}).name || '').trim().slice(0, 60);
    if (!name) return res.status(400).json({ error: 'Give it a name.' });
    if (req.params.id === 'main') db.update('users', user.id, { twoFactorMainName: name });
    else db.update('users', user.id, { twoFactorDevices: (user.twoFactorDevices || []).map(d => (d.id === req.params.id ? { ...d, name } : d)) });
    res.json({ ok: true, authenticators: listOf(db.findById('users', user.id)) });
  });

  // Note: there is deliberately no /2fa/disable route. There's no "off" state
  // to disable into — someone wanting a different channel just runs
  // /2fa/setup + /2fa/enable again with the method they want; that flow already
  // handles switching to or from any of the three methods at any time.

  return { passkeyRouter, twoFactorRouter };
}

module.exports = { createAuthRouters };
