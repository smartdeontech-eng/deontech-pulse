// @deontech/identity — who the person is and how they prove it.
//
// totp / passwordPolicy / getRP are the primitives. createSession is the
// machinery behind every sign-in path: the session cookie, the login log, the
// one-time codes, the WebAuthn challenge cookies, the lockout, and the account
// tiers that stop a lower-tier account taking over a higher one.
//
// Note what is NOT here: the @simplewebauthn/server re-export and the
// jsonwebtoken import. Both are the app's own dependency, at the app's own
// version; this package has none.
const totp = require('./totp');
const passwordPolicy = require('./passwordPolicy');
const { getRP } = require('./rp');
const { createSession, NOT_A_FAILURE, OTP_TTL_MS } = require('./session');
const { createAuthRouters } = require('./routers');

module.exports = { totp, passwordPolicy, getRP, createSession, createAuthRouters, NOT_A_FAILURE, OTP_TTL_MS };
