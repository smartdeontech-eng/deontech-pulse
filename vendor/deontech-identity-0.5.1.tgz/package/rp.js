// Working out the Relying Party for a passkey request.
//
// Split out of webauthn.js deliberately. This is the only part of that file
// that ever differed between the two apps, it is the only part with any logic
// worth testing, and it does not depend on @simplewebauthn/server at all —
// welding it to that import only meant it could not be tested without one.
const { appConfig } = require('@deontech/config');

// The RP ID must be the site's registrable domain (e.g. "aotc-track.com")
// and the origin the full URL the browser sees (e.g. "https://aotc-track.com").
// In dev that's "localhost" / "http://localhost:3000". Both are derived from
// the incoming request so the same code works locally and in production, with
// explicit overrides for reverse-proxy setups where the Host header or
// protocol can't be trusted.
function getRP(req) {
  const { webauthn } = appConfig();

  // Host header without the port -> the RP ID.
  const host = (req.get('host') || 'localhost').split(':')[0];
  // req.protocol honours x-forwarded-proto when `trust proxy` is set (it is,
  // in production), so this is https behind nginx and http on localhost.
  const proto = req.protocol || 'http';
  const derivedOrigin = `${proto}://${req.get('host') || 'localhost:3000'}`;

  return {
    rpName: webauthn.rpName,
    rpID: webauthn.rpID || host,
    origin: webauthn.origin || derivedOrigin,
  };
}

module.exports = { getRP };
