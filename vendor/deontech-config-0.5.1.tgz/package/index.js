// ---- The branding boundary ----
//
// This is the piece that replaces find-and-replace.
//
// Every difference between AOTC Track and Smart DeonTech in the shared files
// was a name: 'AOTC Track' vs 'Smart DeonTech', 'PCG Adabraka Official Town
// Congregation' vs 'Smart DeonTech Limited', 'aotc-track.com' vs
// 'smartdeontech.com'. Copying the file and rewriting the strings is what made
// the two codebases drift apart, because once a file has been rewritten it can
// no longer be pulled back from the other side.
//
// So: no package in this workspace ever hardcodes a product name, a legal
// entity, a domain or a data directory. The app declares them once at boot and
// the packages read them from here.
//
// Rules for anything added to this file later:
//   1. It is a NAME or a PATH, not a behaviour. If you find yourself adding a
//      boolean so one app can take a different code path, the thing you are
//      configuring belongs in that app, not in a shared package.
//   2. It has no sensible shared default. `productName` has none — every app
//      must state it. Something every app would set the same way should just
//      be the value in the package.

let current = null;

const REQUIRED = ['productName', 'legalName', 'dataDir'];

// Called once, at the top of the app's server.js, before any package is used.
function configureApp(cfg) {
  if (!cfg || typeof cfg !== 'object') {
    throw new Error('configureApp() needs a config object.');
  }

  const missing = REQUIRED.filter(k => !cfg[k] || !String(cfg[k]).trim());
  if (missing.length) {
    // Fail at boot, loudly. The alternative is a package quietly falling back
    // to a default and an app going to production emailing people under the
    // wrong company name.
    throw new Error(
      `configureApp() is missing required field(s): ${missing.join(', ')}. ` +
      'Every @deontech package reads its names from here.'
    );
  }

  const webauthn = cfg.webauthn || {};

  current = Object.freeze({
    // What the software calls itself in the interface, in email subject lines
    // and on a passkey prompt. 'AOTC Track', 'Smart DeonTech'.
    productName: String(cfg.productName).trim(),

    // Who is legally sending the email or issuing the document. The
    // congregation, or the limited company. Almost never the same string as
    // productName, which is why they are two fields and not one.
    legalName: String(cfg.legalName).trim(),

    // Absolute path to the app's data/ directory.
    //
    // This one exists because of a real bug waiting to happen: utils/settings.js
    // resolved its own path with `path.join(__dirname, '..', 'data')`. That is
    // correct while the file sits in the app's own utils/ folder and silently
    // wrong the moment it is loaded from node_modules/@deontech/db — it would
    // resolve inside node_modules and every setting would read as default.
    // Shared code cannot locate the app's data by walking up from itself.
    dataDir: String(cfg.dataDir).trim(),

    // Public site, when there is one. Optional: used for links in email.
    domain: cfg.domain ? String(cfg.domain).trim() : '',

    webauthn: Object.freeze({
      // What the browser shows in the passkey dialog. Defaults to the product
      // name, which is what both apps set it to by hand.
      rpName: webauthn.rpName ? String(webauthn.rpName) : String(cfg.productName).trim(),
      // Overrides for reverse-proxy setups where the Host header or protocol
      // can't be trusted. Left empty, the values are derived per request.
      rpID: webauthn.rpID || process.env.WEBAUTHN_RP_ID || '',
      origin: webauthn.origin || process.env.WEBAUTHN_ORIGIN || '',
    }),
  });

  return current;
}

function appConfig() {
  if (!current) {
    throw new Error(
      'configureApp() has not been called. Add it to the top of server.js, ' +
      'before any route or util is required.'
    );
  }
  return current;
}

function isConfigured() {
  return current !== null;
}

// Tests only. Not exported through the package index on purpose.
function __resetForTests() {
  current = null;
}

module.exports = { configureApp, appConfig, isConfigured, __resetForTests };
