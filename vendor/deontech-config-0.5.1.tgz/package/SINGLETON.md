# Why @deontech/config is a peer dependency

`configureApp()` writes to a module-level variable and `appConfig()` reads it.
That means every package must see the **same instance** of this module.

If `@deontech/identity` declared `@deontech/config` as an ordinary dependency,
npm would be free to install a private copy inside
`node_modules/@deontech/identity/node_modules/@deontech/config`. The app would
then call `configureApp()` on one instance while identity read a different,
unconfigured one — and the failure would be `appConfig() has not been called`
at the first passkey login, in production, with nothing obviously wrong in the
code.

Declaring it as a peer says what is actually true: the host application
provides it, exactly once. `peerDependenciesMeta` is deliberately NOT set to
optional — it is required, and a missing peer should be a loud warning.
