// Email. Uses nodemailer if SMTP is configured via environment variables;
// otherwise it safely does nothing (logs and returns) so the app never crashes
// or blocks on a missing or broken mail server.
//
// Configure in .env:
//   SMTP_HOST, SMTP_PORT, SMTP_SECURE ("true"/"false"), SMTP_USER, SMTP_PASS
//   MAIL_FROM        e.g. "Smart DeonTech <no-reply@example.com>"
//   NOTIFY_EMAIL     where operational alerts are sent
//   APP_URL          base URL of the app, used in links (optional)
//
// EXTRACTED: this is the part of utils/mailer.js that both apps actually use —
// the transport, sendMail, and the two account emails. It is deliberately NOT
// the whole file.
//
// Both copies of utils/mailer.js are 425 lines and differ by 16, and both
// contain sendInvoiceEmail, sendPaymentEmail, sendInstallmentReminderEmail,
// sendJobClosedEmail, sendPackingListEmail and sendLowStockEmail. aotc-track
// calls NONE of those six. They are Smart DeonTech's business email, copied
// whole into a church reporting system with the strings rewritten, so that
// AOTC Track is currently capable of emailing an invoice "from PCG Adabraka
// Official Town Congregation". Around 300 of its 425 mailer lines are dead.
//
// Business templates belong to whoever has invoices. They stay in
// smart-deontech/utils/mailer.js, which now wires this package underneath them.
const { appConfig } = require('@deontech/config');

function createMailer({ nodemailer, getSettings, logNotification }) {
  if (!nodemailer || typeof nodemailer.createTransport !== 'function') {
    throw new Error("createMailer() needs the app's nodemailer module.");
  }
  if (typeof getSettings !== 'function') {
    throw new Error('createMailer() needs getSettings — the currency symbol comes from the app.');
  }
  if (typeof logNotification !== 'function') {
    throw new Error('createMailer() needs logNotification — a send failure that only reaches the console is the bug this package exists to avoid.');
  }

  let injectedTransport = null; // for tests
  let cachedTransport = null;

  // Allow tests to inject a fake transport (an object with sendMail()).
  function setTransport(t) {
    injectedTransport = t;
    cachedTransport = null;
  }

  function getTransport() {
    if (injectedTransport) return injectedTransport;
    if (cachedTransport) return cachedTransport;
    if (!process.env.SMTP_HOST) return null; // not configured
    cachedTransport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    });
    return cachedTransport;
  }

  function money(n) {
    return (getSettings().currencySymbol || '₵') + Number(n || 0).toFixed(2);
  }

  async function sendMail({ to, subject, html, attachments }) {
    if (!to) return { skipped: 'no-recipient' };
    const transport = getTransport();
    if (!transport) {
      console.log(`[mail] SMTP not configured — skipping "${subject}" to ${to}`);
      return { skipped: 'not-configured' };
    }
    // Was hardcoded per app ('PCG Adabraka Official Town Congregation …' /
    // 'Smart DeonTech Limited …'). It is the legal sender, not the product.
    const from = process.env.MAIL_FROM || `${appConfig().legalName} <no-reply@localhost>`;
    try {
      const info = await transport.sendMail({ from, to, subject, html, attachments });
      console.log(`[mail] sent "${subject}" to ${to}`);
      return info;
    } catch (err) {
      // Never let email failure break the business action.
      console.error(`[mail] failed to send "${subject}" to ${to}:`, err.message);
      logNotification({
        level: 'error', source: 'email',
        message: `Email "${subject}" to ${to} failed: ${err.message}`,
        meta: { to, subject },
      });
      return { error: err.message };
    }
  }

  // ---- Account emails ----
  // Both apps have staff who forget passwords. These two differed only by the
  // product name, which now comes from @deontech/config.

  async function sendPasswordResetEmail(user, resetLink) {
    const { productName } = appConfig();
    const html = `
    <div style="font-family:Arial,sans-serif;color:#1a1a1a">
      <h2 style="color:#0B4C86">Reset your password</h2>
      <p>Hi ${user.name},</p>
      <p>We received a request to reset the password for your ${productName} account (${user.email}).</p>
      <p><a href="${resetLink}" style="background:#0B4C86;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;display:inline-block">Reset password</a></p>
      <p style="color:#666;font-size:13px">This link expires in 1 hour, and can be used once. If it has expired, ask for another from the sign-in page.</p>
      <p style="color:#666;font-size:13px">If you didn't request this, you can safely ignore this email — your password will not change, and nobody has been told you have an account.</p>
    </div>`;
    return sendMail({ to: user.email, subject: `Reset your ${productName} password`, html });
  }

  async function sendForgotEmailRequest({ user, requestedName, admins }) {
    const recipients = (admins || []).map(a => a.email).filter(Boolean);
    const to = recipients.join(',') || process.env.NOTIFY_EMAIL;
    if (!to) return { skipped: 'no-admin-email' };
    const html = `
    <div style="font-family:Arial,sans-serif;color:#1a1a1a">
      <h2 style="color:#0B4C86">Login email recovery request</h2>
      <p>Someone using the phone number on file for <strong>${user.name}</strong> asked to recover their login email
         ${requestedName ? `(they identified themselves as "${requestedName}")` : ''}.</p>
      <p>Their account email is: <strong>${user.email}</strong></p>
      <p style="color:#666;font-size:13px">Please verify their identity before sharing this, then help them sign in.</p>
    </div>`;
    return sendMail({ to, subject: 'Staff login recovery request', html });
  }

  return { setTransport, getTransport, sendMail, money, sendPasswordResetEmail, sendForgotEmailRequest };
}

module.exports = { createMailer };
