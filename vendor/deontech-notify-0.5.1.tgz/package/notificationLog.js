// System / provider alerts that would otherwise only ever appear in the server
// console and then be gone — SMS delivery failures (including gateway
// account-level alerts, e.g. mNotify flagging the sending account), email
// delivery failures, low-stock crossings, and backup failures. Written here so
// they are visible from the app's Notifications tab instead of silently
// scrolling off a terminal nobody is watching. Append-only, same pattern as
// login_logs / activity_logs.
//
// EXTRACTED: aotc-track's version is exactly the db write below. Smart
// DeonTech's added a web-push fan-out on top — but that fan-out is written in
// Smart DeonTech's vocabulary: it routes low-stock alerts to holders of
// 'products.manage' and links to '/settings.html'. Neither means anything in a
// church reporting system.
//
// So the write is shared and the fan-out is a hook. An app that wants alerts to
// reach a phone passes onNotification and decides there who should get it.

function createNotificationLog({ db, onNotification }) {
  if (!db || typeof db.insert !== 'function') {
    throw new Error('createNotificationLog(db) needs the app datastore (must expose insert()).');
  }

  // level: 'error' | 'warning'
  // source: 'sms' | 'email' | 'stock' | 'backup'
  function logNotification({ level = 'error', source, message, meta }) {
    try {
      db.insert('notifications', {
        level,
        source: source || '',
        message: message || '',
        meta: meta || null,
        readAt: null,
      });
    } catch (e) {
      console.error('[notifications] failed to write entry:', e.message);
    }

    if (typeof onNotification === 'function') {
      // Wrapped so a fan-out failure can never break the caller — the same
      // policy the whole of this package runs on.
      try {
        onNotification({ level, source, message, meta });
      } catch (e) {
        console.error('[notifications] handler failed:', e.message);
      }
    }
  }

  return { logNotification };
}

module.exports = { createNotificationLog };
