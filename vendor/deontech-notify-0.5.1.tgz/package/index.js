// @deontech/notify — how the app reaches a person, and how it records that it
// couldn't.
//
// What is here: the mail transport, the SMS gateway, the two account emails,
// and the operational notification log. What is NOT here: message templates
// about invoices, payments, job cards or stock — those belong to the app that
// has customers — and web push, whose two implementations are genuinely
// different designs rather than one design copied twice.
const { createMailer } = require('./mailer');
const { createSms } = require('./sms');
const { createNotificationLog } = require('./notificationLog');

module.exports = { createMailer, createSms, createNotificationLog };
