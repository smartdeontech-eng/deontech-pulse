// App settings shown on letterheads and used across the interface. Stored as a
// single JSON file (not the array-based db store, since there's only ever one
// settings record) so it survives restarts and is editable from the app
// instead of being hardcoded in a PDF module.
//
// EXTRACTED: the machinery was identical in both apps — defaults, spread the
// stored file over them, fall back to defaults if the file is corrupt, merge
// on update. What differed was 100% content: the congregation's presbytery and
// Session Clerk on one side, invoice terms and a Google review URL on the
// other. So the app supplies `defaults`; the package supplies the store.
//
// Two changes from the copied version, both required by extraction:
//
//  1. `dataDir` is injected. The original resolved its own location with
//     `path.join(__dirname, '..', 'data')`, which is correct in the app's
//     utils/ folder and silently wrong inside node_modules — it would have
//     read and written settings.json in the package's own directory, so every
//     setting would come back as its default and every save would vanish.
//
//  2. The corrupt-file path logs which file it is. It still returns defaults
//     rather than throwing: unlike a business collection, a missing letterhead
//     is a cosmetic problem and should not stop the app from starting.
const fs = require('fs');
const path = require('path');

function createSettingsStore({ dataDir, defaults, fileName = 'settings.json' }) {
  if (!dataDir) throw new Error('createSettingsStore() needs dataDir.');
  if (!defaults || typeof defaults !== 'object') {
    throw new Error('createSettingsStore() needs the app\'s defaults object.');
  }

  const DEFAULTS = Object.freeze({ ...defaults });
  const SETTINGS_PATH = path.join(dataDir, fileName);

  function getSettings() {
    if (!fs.existsSync(SETTINGS_PATH)) return { ...DEFAULTS };
    try {
      const raw = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
      return { ...DEFAULTS, ...raw };
    } catch (e) {
      console.error(`[settings] corrupt ${fileName}, using defaults:`, e.message);
      return { ...DEFAULTS };
    }
  }

  function updateSettings(patch) {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    const merged = { ...getSettings(), ...patch };
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(merged, null, 2));
    return merged;
  }

  return { getSettings, updateSettings, DEFAULTS };
}

module.exports = { createSettingsStore };
