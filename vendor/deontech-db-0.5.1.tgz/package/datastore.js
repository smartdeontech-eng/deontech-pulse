// Lightweight JSON-file datastore. No native build tools required.
// Good fit for small/medium business data volumes (thousands of records).
//
// EXTRACTED FROM BOTH FORKS. This file is where the copy-fork actually cost
// money, so it is worth being precise about what came from where:
//
//   * The corrupt-file behaviour is Smart DeonTech's. Its fork made a bad
//     JSON file THROW; aotc-track's fork still returns [] and carries on,
//     which means a corrupt file reports the collection as empty and the next
//     write persists that emptiness over the real records. Adopting this
//     package fixes that bug in AOTC Track — and changes its behaviour, which
//     is called out in MIGRATION.md.
//
//   * mutate() is aotc-track's. Its fork added an atomic read-modify-write so
//     two requests changing the same record cannot lose each other's change;
//     Smart DeonTech still has that race. Adopting this package fixes it there.
//
// Neither app could use the other's fix. That is the whole argument for this
// workspace, in one file.
//
// The data directory is injected. The two apps read it from different
// environment variables (AOTC_DATA_DIR and DATA_DIR), and that stays each
// app's business — see each one's utils/dataDir.js.
const fs = require('fs');
const path = require('path');

function createDatastore({ dataDir }) {
  if (!dataDir) throw new Error('createDatastore() needs dataDir.');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  function filePath(collection) {
    return path.join(dataDir, `${collection}.json`);
  }

  function readAll(collection) {
    const fp = filePath(collection);
    if (!fs.existsSync(fp)) return [];
    const raw = fs.readFileSync(fp, 'utf8').trim();
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch (e) {
      // Keep a copy, then refuse to continue. Returning [] here reported the
      // collection as empty — "no payments were ever received", "there are no
      // procurement orders" — and the next write persisted that emptiness over
      // the real records. A visible failure is far better than silently
      // serving, and then saving, an empty set of the business's books.
      const backup = fp + `.corrupt.${Date.now()}.bak`;
      fs.copyFileSync(fp, backup);
      console.error(`[db] ${collection}.json is not valid JSON. Copy saved to ${path.basename(backup)}.`, e);
      throw new Error(
        `Data file for "${collection}" is not valid JSON and could not be read. ` +
        `A copy was saved as ${path.basename(backup)}. ` +
        `Restore ${collection}.json from the most recent folder in backups/ before using the app.`
      );
    }
  }

  function writeAll(collection, records) {
    const fp = filePath(collection);
    const tmp = fp + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(records, null, 2));
    fs.renameSync(tmp, fp); // atomic on same filesystem
  }

  function nextId(collection) {
    const records = readAll(collection);
    const max = records.reduce((m, r) => Math.max(m, r.id || 0), 0);
    return max + 1;
  }

  function insert(collection, record) {
    const records = readAll(collection);
    const id = nextId(collection);
    // NOTE: `record` is spread AFTER id, so a record carrying its own `id`
    // overrides the generated one. Both forks behave this way and some code
    // may rely on it (re-importing a record with its original id). Preserved
    // deliberately; there is a test pinning it so it cannot change by accident.
    const withId = { id, ...record, createdAt: new Date().toISOString() };
    records.push(withId);
    writeAll(collection, records);
    return withId;
  }

  function findAll(collection, filterFn) {
    const records = readAll(collection);
    return filterFn ? records.filter(filterFn) : records;
  }

  function findOne(collection, filterFn) {
    return readAll(collection).find(filterFn) || null;
  }

  function findById(collection, id) {
    return findOne(collection, r => r.id === Number(id));
  }

  // NOTE: `patch` is spread after the existing record, so a patch containing
  // an `id` rewrites the record's identity. mutate() below deliberately does
  // not allow that. The asymmetry is inherited from both forks and is pinned
  // by a test rather than quietly fixed — 221 call sites across the two apps
  // depend on this function, and changing identity handling during an
  // extraction is how a refactor turns into an outage. Worth revisiting on
  // its own, with the call sites in front of you.
  function update(collection, id, patch) {
    const records = readAll(collection);
    const idx = records.findIndex(r => r.id === Number(id));
    if (idx === -1) return null;
    records[idx] = { ...records[idx], ...patch, updatedAt: new Date().toISOString() };
    writeAll(collection, records);
    return records[idx];
  }

  function remove(collection, id) {
    const records = readAll(collection);
    const filtered = records.filter(r => r.id !== Number(id));
    writeAll(collection, filtered);
    return filtered.length !== records.length;
  }

  // Atomic read-modify-write of ONE record. `fn` receives a copy of the current
  // record and returns the new version (or a falsy value to leave it unchanged).
  // Because the read and write happen in a single synchronous call, two requests
  // mutating the same record can't interleave and lose each other's change — use
  // this instead of findById()+…await…+update() when appending to an array or
  // otherwise deriving the new value from the current one.
  function mutate(collection, id, fn) {
    const records = readAll(collection);
    const idx = records.findIndex(r => r.id === Number(id));
    if (idx === -1) return null;
    const next = fn({ ...records[idx] });
    if (!next) return records[idx];
    records[idx] = { ...next, id: records[idx].id, updatedAt: new Date().toISOString() };
    writeAll(collection, records);
    return records[idx];
  }

  return { readAll, writeAll, insert, findAll, findOne, findById, update, remove, mutate, filePath };
}

module.exports = { createDatastore };
