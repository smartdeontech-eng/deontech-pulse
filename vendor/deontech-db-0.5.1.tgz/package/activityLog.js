// Business-action audit trail — "who did what", so an admin can answer
// "who created this record" or "who deleted that one" from the app instead of
// guessing. Append-only ledger, same pattern as login_logs.
// Logging never blocks or fails the caller — an audit-trail gap is far
// better than a broken business action (same policy as email/SMS sends).
//
// EXTRACTED: byte-identical in both apps. Two changes, both deliberate:
//
//  1. The datastore is INJECTED rather than required. A package cannot
//     `require('./db')` and reach the app's data — it would find its own
//     folder inside node_modules. Passing db in also means this module can be
//     tested without touching a filesystem at all.
//
//  2. The doc comment used to list Smart DeonTech's entity types
//     ('invoice' | 'customer' | 'product' | 'job_card') — which AOTC Track
//     inherited verbatim and which was wrong there from the first day. Shared
//     code does not get to name one app's nouns. entityType is now free text
//     and each app documents its own.

function createActivityLog(db) {
  if (!db || typeof db.insert !== 'function') {
    throw new Error('createActivityLog(db) needs the app datastore (must expose insert()).');
  }

  // action: short verb phrase, e.g. "Created invoice", "Voided invoice"
  // entityType: the app's own noun for the thing, e.g. 'invoice', 'minutes'
  // entityLabel: human-readable reference shown in the log, e.g. a document
  //   number or a person's name
  // snapshot: optional — the full record as it existed right before a hard
  //   delete. Hard-deleting a record removes it from its own data file
  //   entirely, so this is the only place its contents survive afterward. Not
  //   shown in the plain activity table (it's the full object, not a one-line
  //   detail) but it's there in activity_logs.json if the deletion is ever
  //   questioned later.
  function logActivity({ userId, userName, action, entityType, entityId, entityLabel, detail, snapshot }) {
    try {
      db.insert('activity_logs', {
        userId: userId != null ? userId : null,
        userName: userName || 'System',
        action,
        entityType: entityType || '',
        entityId: entityId != null ? entityId : null,
        entityLabel: entityLabel || '',
        detail: detail || '',
        ...(snapshot !== undefined ? { snapshot } : {}),
      });
    } catch (e) {
      console.error('[activity-log] failed to write entry:', e.message);
    }
  }

  return { logActivity };
}

module.exports = { createActivityLog };
