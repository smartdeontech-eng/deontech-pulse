// @deontech/db — the data layer.
//
// createDatastore is the merge point of the two forks: Smart DeonTech's
// corrupt-file throw and aotc-track's mutate(). See datastore.js.
const { createDatastore } = require('./datastore');
const { createSqliteDatastore } = require('./sqliteDatastore');
const { createActivityLog } = require('./activityLog');
const { createSettingsStore } = require('./settings');

// Two backends, one contract. An app picks by which factory it calls — there
// is no flag inside either one. createDatastore() stays the default and
// nothing about the apps already on it changes; createSqliteDatastore() is for
// an app that needs relational queries or more than one process on the data.
// See the header of sqliteDatastore.js for why the second exists.
module.exports = { createDatastore, createSqliteDatastore, createActivityLog, createSettingsStore };
