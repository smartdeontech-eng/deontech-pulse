// ---- Session and permission guards ----
//
// The machinery, not the vocabulary. `fundraising.approve` and `invoices.void`
// are not two settings of one system, they are two businesses — so PERMISSIONS
// and ROLE_DEFAULT_PERMISSIONS stay in each app's own middleware/auth.js. What
// is shared is the code that checks them, which was character-for-character the
// same in both forks apart from the names of the privileged roles.
//
// Injected rather than imported:
//
//   db   — a shared package cannot require('../utils/db') and reach the app's
//          data. Same reason as @deontech/db's activity log.
//   jwt  — the app owns its jsonwebtoken version. Importing it here would put
//          the app's dependency inside shared code and, because Node resolves
//          a symlinked package from its real path, would make this package
//          look for it in the core repo rather than in the app that has it.
//          That mistake was made once already, with @simplewebauthn/server.
//
// The two apps express the admin tiers differently and both are covered by the
// same code:
//
//   AOTC Track        admin + localadmin, localadmin holds EVERY right
//                     -> secondaryAdminRoles: ['localadmin'], adminOnlyPermissions: []
//   Smart DeonTech    admin + manager, manager holds everything EXCEPT
//                     settings.manage
//                     -> secondaryAdminRoles: ['manager'],
//                        adminOnlyPermissions: ['settings.manage']
//
// With an empty adminOnlyPermissions the second tier passes every check, which
// is exactly AOTC Track's "localadmin bypasses requirePermission" behaviour.
// One implementation, no branch on which app is running.

function createAuth({
  db,
  jwt,
  jwtSecret,
  adminRole = 'admin',
  secondaryAdminRoles = [],
  adminOnlyPermissions = [],
  usersCollection = 'users',
}) {
  if (!db || typeof db.findById !== 'function') {
    throw new Error('createAuth() needs the app datastore (must expose findById()).');
  }
  if (!jwt || typeof jwt.verify !== 'function') {
    throw new Error("createAuth() needs the app's jsonwebtoken module.");
  }
  if (!jwtSecret) {
    // No insecure fallback on purpose — the app's server.js refuses to start
    // if JWT_SECRET is missing or weak. Failing here too means a script that
    // imports this without going through that check cannot quietly run on a
    // well-known default secret.
    throw new Error('createAuth() needs jwtSecret. The app must refuse to start without one.');
  }

  const SECONDARY = new Set(secondaryAdminRoles);
  const ADMIN_ONLY = new Set(adminOnlyPermissions);

  const NOT_LOGGED_IN = { error: 'Not logged in.' };
  const EXPIRED = { error: 'Session expired. Please log in again.' };
  const NO_RIGHT = { error: 'You have not been given permission to do this. Ask an admin for access.' };
  const ADMIN_ONLY_MSG = { error: 'Only the main administrator can change this. Ask an admin for access.' };

  // Bypasses the stored permissions array entirely — by role, not by whatever
  // happens to be in that array.
  function isPrivileged(user) {
    return !!user && (user.role === adminRole || SECONDARY.has(user.role));
  }

  // Every real session token carries the account's sessionVersion at the time
  // it was issued. Bumping that number (password reset, account recovery) makes
  // every token signed before the bump fail on its very next request — the
  // closest thing a stateless JWT setup has to "log out everywhere", which
  // matters most for kicking an attacker off a compromised account the moment
  // it is reset.
  function requireAuth(req, res, next) {
    const token = req.cookies.token;
    if (!token) return res.status(401).json(NOT_LOGGED_IN);
    try {
      const payload = jwt.verify(token, jwtSecret);
      if (payload.purpose && payload.purpose !== 'session') {
        return res.status(401).json(NOT_LOGGED_IN);
      }
      const fresh = db.findById(usersCollection, payload.id);
      if (!fresh) return res.status(401).json(EXPIRED);
      if ((fresh.sessionVersion || 0) !== (payload.sv || 0)) {
        return res.status(401).json({
          error: 'Your session was signed out remotely (e.g. a password reset). Please log in again.',
        });
      }
      req.user = payload;
      next();
    } catch (e) {
      return res.status(401).json(EXPIRED);
    }
  }

  function requireRole(...roles) {
    return (req, res, next) => {
      if (!req.user) return res.status(401).json(NOT_LOGGED_IN);
      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ error: 'You do not have permission to do this.' });
      }
      next();
    };
  }

  // Does this user (a req.user token payload OR a stored user row) hold the
  // named right? Same rules as requirePermission, but as a plain predicate so
  // route handlers can BRANCH on a permission rather than reject outright —
  // e.g. a job list serving the full board to jobs.manage holders and only the
  // caller's own assigned jobs to a jobs.field technician.
  // Always re-reads the stored user so a permission change takes effect without
  // the person having to log in again. `row` lets a caller that has already
  // read the user pass it in, so checking several rights costs one read.
  function userHasPermission(user, permission, row) {
    if (!user) return false;
    if (user.role === adminRole) return true;
    if (SECONDARY.has(user.role)) return !ADMIN_ONLY.has(permission);
    const fresh = row !== undefined ? row : db.findById(usersCollection, user.id);
    const perms = (fresh && fresh.permissions) || user.permissions || [];
    return perms.includes(permission);
  }

  // Grants access if the user is privileged OR has been given the named right.
  // Reads the user fresh so permission changes take effect without re-login.
  function requirePermission(permission) {
    return (req, res, next) => {
      if (!req.user) return res.status(401).json(NOT_LOGGED_IN);
      if (req.user.role === adminRole) return next();
      if (SECONDARY.has(req.user.role)) {
        if (!ADMIN_ONLY.has(permission)) return next();
        return res.status(403).json(ADMIN_ONLY_MSG);
      }
      const fresh = db.findById(usersCollection, req.user.id);
      const perms = (fresh && fresh.permissions) || [];
      if (!perms.includes(permission)) return res.status(403).json(NO_RIGHT);
      next();
    };
  }

  // Passes if the caller holds ANY ONE of the listed rights. Used on endpoints
  // two different kinds of user legitimately reach by different routes — the
  // handler itself is then responsible for scoping what each one sees.
  function requireAnyPermission(...permissions) {
    return (req, res, next) => {
      if (!req.user) return res.status(401).json(NOT_LOGGED_IN);
      // One read for the whole check, however many rights are listed.
      const row = isPrivileged(req.user) ? null : db.findById(usersCollection, req.user.id);
      if (permissions.some(p => userHasPermission(req.user, p, row))) return next();
      return res.status(403).json(NO_RIGHT);
    };
  }

  return {
    requireAuth,
    requireRole,
    requirePermission,
    requireAnyPermission,
    userHasPermission,
    isPrivileged,
  };
}

module.exports = { createAuth };
